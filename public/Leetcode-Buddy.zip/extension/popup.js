// Define loadProblemData at the top of the file
async function loadProblemData() {
  try {
    // Get the active tab ID
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    const activeTabId = tabs[0].id;

    // Check if we're on a LeetCode problem page
    let isLeetCodeProblem = tabs[0].url.includes('leetcode.com/problems/');

    // If not on LeetCode, look up stored problem by tab ID
    const { tabProblems, currentProblem } = await chrome.storage.local.get(['tabProblems', 'currentProblem']);
    const storedProblems = tabProblems || {};

    // Use problem from current tab if available, otherwise fall back to last problem
    const problemToShow = isLeetCodeProblem ? currentProblem : storedProblems[activeTabId] || currentProblem;

    if (!problemToShow) {
      document.getElementById('noDetection').classList.remove('hidden');
      document.getElementById('hintsContainer').classList.add('hidden');
      document.getElementById('problemInfo').classList.add('hidden');
      return;
    }

    // Update problem info in the UI
    document.getElementById('problemTitle').textContent = problemToShow.title || 'Unknown Problem';
    document.getElementById('problemDifficulty').textContent = `Difficulty: ${problemToShow.difficulty || 'Unknown'}`;

    // Load existing hints for the problem
    await loadExistingHints(problemToShow.id);

    // Show the hints container
    document.getElementById('hintsContainer').classList.remove('hidden');
    document.getElementById('problemInfo').classList.remove('hidden');
    document.getElementById('noDetection').classList.add('hidden');

    // Cache the current problem
    cacheCurrentProblem(problemToShow);
  } catch (error) {
    console.error('Error loading problem data:', error);
    alert('Failed to load problem data. Please try again.');
  }
}

// Function to load existing hints for a problem
async function loadExistingHints(problemId) {
  const { hintsUsed } = await chrome.storage.local.get('hintsUsed');
  const problemHints = (hintsUsed && hintsUsed[problemId]) ? hintsUsed[problemId] : [];

  const hintsList = document.getElementById('hintsList');
  if (!hintsList) return;

  hintsList.innerHTML = '';

  // Display existing hints
  problemHints.forEach((hint, index) => {
    const hintElement = document.createElement('div');
    hintElement.className = 'hint';
    hintElement.textContent = `Hint ${index + 1}: ${hint}`;
    hintsList.appendChild(hintElement);
  });

  // Enable/disable solution button based on hint count
  const solutionBtn = document.getElementById('getSolutionBtn');
  const hintCounter = document.getElementById('hintCounter');
  if (!solutionBtn || !hintCounter) return;

  const hintsNeeded = 4;
  const hintsGotten = problemHints.length;

  // Update counter text
  hintCounter.textContent = `${hintsGotten}/${hintsNeeded}`;

  if (hintsGotten >= hintsNeeded) {
    solutionBtn.disabled = false;
    hintCounter.className = 'hint-counter-complete';
  } else {
    solutionBtn.disabled = true;
    hintCounter.className = 'hint-counter';
  }
}

// Function to reset hints for the current problem
async function resetHints() {
  try {
    // Get the active tab ID
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    const activeTabId = tabs[0].id;

    // Check if we're on a LeetCode problem page
    let isLeetCodeProblem = tabs[0].url.includes('leetcode.com/problems/');

    // If not on LeetCode, look up stored problem by tab ID
    const { tabProblems, currentProblem, hintsUsed } = await chrome.storage.local.get(['tabProblems', 'currentProblem', 'hintsUsed']);
    const storedProblems = tabProblems || {};

    // Use problem from current tab if available, otherwise fall back to last problem
    const problemToReset = isLeetCodeProblem ? currentProblem : storedProblems[activeTabId] || currentProblem;

    if (!problemToReset) {
      // Just log error instead of showing alert
      console.error('No problem detected to reset hints for.');
      return;
    }

    // Create a copy of hintsUsed
    const updatedHintsUsed = { ...hintsUsed };

    // Remove hints for current problem
    delete updatedHintsUsed[problemToReset.id];

    // Save updated hints
    await chrome.storage.local.set({ hintsUsed: updatedHintsUsed });

    // Update UI
    await loadExistingHints(problemToReset.id);

    // Show visual feedback instead of alert
    const resetBtn = document.getElementById('resetHintsBtn');
    if (resetBtn) {
      const originalText = resetBtn.textContent;
      resetBtn.textContent = 'Done';

      setTimeout(() => {
        resetBtn.textContent = originalText;
      }, 1000);
    }

  } catch (error) {
    console.error('Error resetting hints:', error);
    // Remove the alert here as well
  }
}

// Function to save the API key
async function saveApiKey() {
  const apiKey = document.getElementById('apiKeyInput').value.trim();

  if (!apiKey) {
    alert('Please enter a valid API key');
    return;
  }

  // Test if the API key is valid before saving
  try {
    const response = await fetch('https://lcbackendhost-production.up.railway.app/api/verify-key', {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${apiKey}`
      }
    });

    if (response.ok) {
      // Save the API key
      await chrome.storage.local.set({ apiKey });

      // Hide API key prompt
      const apiKeyPrompt = document.getElementById('apiKeyPrompt');
      if (apiKeyPrompt) apiKeyPrompt.classList.add('hidden');

      // Load problem data
      loadProblemData();
    } else {
      const errorText = await response.text();
      console.error('API key verification failed:', errorText);
      alert('Invalid API key. Please check and try again.');
    }
  } catch (error) {
    console.error('Error verifying API key:', error);
    alert('Could not verify API key. Please check your connection and try again.');
  }
}

// Function to get the next hint
async function getNextHint() {
  const hintBtn = document.getElementById('getHintBtn');
  const originalText = hintBtn ? hintBtn.textContent : '';

  try {
    // Show loading state
    if (hintBtn) {
      hintBtn.textContent = 'Loading...';
      hintBtn.disabled = true;
    }

    // Get the active tab ID
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    const activeTabId = tabs[0].id;

    // Check if we're on a LeetCode problem page
    let isLeetCodeProblem = tabs[0].url.includes('leetcode.com/problems/');

    // If not on LeetCode, look up stored problem by tab ID
    const { tabProblems, currentProblem, apiKey, hintsUsed } = await chrome.storage.local.get(['tabProblems', 'currentProblem', 'apiKey', 'hintsUsed']);
    const storedProblems = tabProblems || {};

    if (!apiKey) {
      alert('API key not set. Please set your API key first.');
      document.getElementById('apiKeyPrompt').classList.remove('hidden');
      return;
    }

    const problemToGetHintFor = isLeetCodeProblem ? currentProblem : storedProblems[activeTabId] || currentProblem;

    if (!problemToGetHintFor || !problemToGetHintFor.id) {
      alert('No problem detected. Please navigate to a LeetCode problem first.');
      return;
    }

    const problemId = problemToGetHintFor.id;
    const existingHints = (hintsUsed && hintsUsed[problemId]) ? hintsUsed[problemId] : [];
    const nextHintIndex = existingHints.length;

    // Build the request URL
    const urlParams = new URLSearchParams({
      index: nextHintIndex,
      title: problemToGetHintFor.title || '',
      difficulty: problemToGetHintFor.difficulty || '',
    });
    const requestUrl = `https://lcbackendhost-production.up.railway.app/api/hints/${problemId}?${urlParams.toString()}`;

    const response = await fetch(requestUrl, {
      headers: {
        'Authorization': `Bearer ${apiKey}`
      }
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error(`API Error: ${response.status} - ${errorText}`);
      throw new Error(`API error: ${response.status}`);
    }

    const data = await response.json();
    const newHint = data.hint;

    // Save the new hint
    const updatedHints = [...existingHints, newHint];
    const allHintsUsed = hintsUsed || {};
    allHintsUsed[problemId] = updatedHints;
    await chrome.storage.local.set({ hintsUsed: allHintsUsed });

    // Refresh the UI
    await loadExistingHints(problemId);
  } catch (error) {
    console.error('Error getting hint:', error);
    alert(`Failed to get hint: ${error.message}`);
  } finally {
    // Reset button state
    if (hintBtn) {
      hintBtn.textContent = originalText;
      hintBtn.disabled = false;
    }
  }
}

// Function to create the solution modal
// Updated createSolutionModal function with improved copy functionality
// Updated createSolutionModal function with improved code extraction
function createSolutionModal(problem, language, solutionText) {
  const solutionModal = document.createElement('div');
  solutionModal.className = 'solution-modal';

  // Extract just the code part from the solution text
  const codeRegex = /```(?:\w+)?\s*([\s\S]*?)```/;
  const codeMatch = solutionText.match(codeRegex);

  // If code is wrapped in code fences (```), extract it, otherwise use the whole text but strip time complexity
  const cleanCodeText = codeMatch ?
    codeMatch[1].trim() :
    solutionText.split(/Time Complexity:|Space Complexity:/)[0].trim();

  solutionModal.innerHTML = `
  <div class="solution-content">
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px;">
      <h3>Solution for ${problem.title}</h3>
      <span class="language-badge">${language.toUpperCase()}</span>
    </div>
    <div class="solution-code-container">
      <pre class="solution-code">${solutionText}</pre>
      <button id="copySolution" class="copy-btn" title="Copy code only">
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect>
          <path d="M5 15H4a2 2 0 01-2-2V4a2 2 0 012-2h9a2 2 0 012 2v1"></path>
        </svg>
      </button>
    </div>
    <div class="modal-actions">
      <button id="closeSolution" class="primary-btn">Close</button>
    </div>
  </div>
`;

  document.body.appendChild(solutionModal);

  // Add copy functionality - UPDATED to copy only the code
  const copySolutionBtn = document.getElementById('copySolution');
  if (copySolutionBtn) {
    copySolutionBtn.addEventListener('click', () => {
      // Copy only the clean code part
      navigator.clipboard.writeText(cleanCodeText)
        .then(() => {
          copySolutionBtn.innerHTML = '✓';
          copySolutionBtn.setAttribute('title', 'Code copied!');
          setTimeout(() => {
            copySolutionBtn.innerHTML = `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect>
              <path d="M5 15H4a2 2 0 01-2-2V4a2 2 0 012-2h9a2 2 0 012 2v1"/>
            </svg>`;
            copySolutionBtn.setAttribute('title', 'Copy code only');
          }, 2000);
        })
        .catch(err => console.error('Could not copy text:', err));
    });
  }

  const closeSolutionBtn = document.getElementById('closeSolution');
  if (closeSolutionBtn) {
    closeSolutionBtn.addEventListener('click', () => {
      solutionModal.remove();
    });
  }
}

// Function to get the solution
async function getSolution() {
  const solutionBtn = document.getElementById('getSolutionBtn');
  const originalHtml = solutionBtn ? solutionBtn.innerHTML : '';

  try {
    // Show loading state
    if (solutionBtn) {
      solutionBtn.innerHTML = 'Loading...';
      solutionBtn.disabled = true;
    }

    // Get the active tab ID
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    const activeTabId = tabs[0].id;

    // Check if we're on a LeetCode problem page
    let isLeetCodeProblem = tabs[0].url.includes('leetcode.com/problems/');

    // If not on LeetCode, look up stored problem by tab ID
    const { tabProblems, currentProblem, apiKey } = await chrome.storage.local.get(['tabProblems', 'currentProblem', 'apiKey']);
    const storedProblems = tabProblems || {};

    if (!apiKey) {
      alert('API key not set. Please set your API key first.');
      document.getElementById('apiKeyPrompt').classList.remove('hidden');
      return;
    }

    const problemToGetSolutionFor = isLeetCodeProblem ? currentProblem : storedProblems[activeTabId] || currentProblem;

    if (!problemToGetSolutionFor) {
      alert('No problem detected. Please navigate to a LeetCode problem first.');
      return;
    }

    const problemId = problemToGetSolutionFor.id;
    const languageSelect = document.getElementById('languageSelect');
    const language = languageSelect ? languageSelect.value : 'python';

    // Build request URL
    const urlParams = new URLSearchParams({ language });
    const requestUrl = `https://lcbackendhost-production.up.railway.app/api/solutions/${problemId}?${urlParams.toString()}`;

    const response = await fetch(requestUrl, {
      headers: {
        'Authorization': `Bearer ${apiKey}`
      }
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error(`Solution API error: ${response.status} - ${errorText}`);
      throw new Error('Failed to fetch solution');
    }

    const data = await response.json();

    // Create solution modal
    createSolutionModal(problemToGetSolutionFor, language, data.solution);

  } catch (error) {
    console.error('Error getting solution:', error);
    alert(`Failed to get solution: ${error.message}`);
  } finally {
    // Reset button state
    if (solutionBtn) {
      solutionBtn.innerHTML = originalHtml;
      solutionBtn.disabled = false;
    }
  }
}

// Function to toggle dark mode
async function toggleDarkMode() {
  const { darkMode } = await chrome.storage.local.get('darkMode');
  const newDarkMode = !darkMode;

  document.body.classList.toggle('dark-mode', newDarkMode);
  const darkModeToggle = document.getElementById('darkModeToggle');
  if (darkModeToggle) {
    darkModeToggle.checked = newDarkMode;
  }
  await chrome.storage.local.set({ darkMode: newDarkMode });
}

// Function to cache problems for offline usage
function cacheCurrentProblem(problem) {
  chrome.storage.local.get(['cachedProblems'], (result) => {
    const cachedProblems = result.cachedProblems || {};

    // Store this problem with timestamp
    cachedProblems[problem.id] = {
      ...problem,
      cachedAt: Date.now()
    };

    // Limit cache to 20 most recent problems
    const problemIds = Object.keys(cachedProblems);
    if (problemIds.length > 20) {
      const oldestProblemId = problemIds.sort(
        (a, b) => cachedProblems[a].cachedAt - cachedProblems[b].cachedAt
      )[0];
      delete cachedProblems[oldestProblemId];
    }

    chrome.storage.local.set({ cachedProblems });
  });
}

// Main initialization
document.addEventListener('DOMContentLoaded', async () => {
  try {
    // Check if the extension context is still valid
    if (!chrome.runtime?.id) {
      throw new Error('Extension context invalidated');
    }

    // Get stored settings
    const { apiKey, darkMode } = await chrome.storage.local.get(['apiKey', 'darkMode']);

    // Apply dark mode if enabled
    if (darkMode) {
      document.body.classList.add('dark-mode');
      const darkModeToggle = document.getElementById('darkModeToggle');
      if (darkModeToggle) {
        darkModeToggle.checked = true;
      }
    }


    // If API key is missing, show the prompt
    if (!apiKey) {
      document.getElementById('apiKeyPrompt').classList.remove('hidden');
      document.getElementById('hintsContainer').classList.add('hidden');
      document.getElementById('problemInfo').classList.add('hidden');
    } else {
      loadProblemData();
    }


    // Safely set up event listeners
    const setupEventListener = (id, event, handler) => {
      const element = document.getElementById(id);
      if (element) element.addEventListener(event, handler);
    };

    setupEventListener('darkModeToggle', 'click', toggleDarkMode);
    setupEventListener('getHintBtn', 'click', getNextHint);
    setupEventListener('getSolutionBtn', 'click', getSolution);
    setupEventListener('saveApiKey', 'click', saveApiKey);
    setupEventListener('resetHintsBtn', 'click', resetHints);

  } catch (error) {
    console.error('Extension error:', error);

    // Simple error UI
    const container = document.querySelector('.container');
    if (container) {
      container.innerHTML = `
        <div style="text-align: center; padding: 20px;">
          <h2 style="color: var(--secondary-color);">Extension Needs a Refresh</h2>
          <p>The extension context has been lost. This usually happens after Chrome updates or when the extension is reloaded.</p>
          <button id="reloadBtn" class="primary-btn" style="margin-top: 15px;">
            Reload Extension
          </button>
        </div>
      `;

      const reloadBtn = document.getElementById('reloadBtn');
      if (reloadBtn) {
        reloadBtn.addEventListener('click', () => {
          chrome.runtime.reload();
        });
      }
    }
  }
});